package com.rest.jersey.messenger.exception;

public class DataNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 3534038357824592632L;

	public DataNotFoundException(String message) {
		super(message);
	}

	
	
}
